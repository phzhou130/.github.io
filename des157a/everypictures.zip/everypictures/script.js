(function(){

    'use strict';

    console.log("reading js");

   


})();
 window.addEventListener('load',function()
    {
        // let backimages1=document.getElementById('backimages1');
        // backimages1.scrollIntoView;
    //    window.addEventListener('scroll',function(){

        let illustration=document.getElementById('illustration');
        illustration.addEventListener('scroll',function(){
            let backimages1=document.getElementById('backimages1');

            let backimages2=document.getElementById('backimages2');
            let backimages3=document.getElementById('backimages3');
            let backimages4=document.getElementById('backimages4');
            let backimages5=document.getElementById('backimages5');
            
            backimages1.addEventListener('scroll', function(){
                backimages2.scrollIntoView();
            });
            backimages2.addEventListener('scroll', function(){
                backimages3.scrollIntoView();
            });
            backimages3.addEventListener('scroll', function(){
                backimages4.scrollIntoView();
            });
            backimages5.addEventListener('scroll', function(){
                backimages5.scrollIntoView();
            });    
        });

        // let backimages2=document.getElementById('backimages2');
        // backimages2.addEventListener('scroll',function(){
        //     let backimages3=document.getElementById('backimages3');
        //     backimages3.scrollIntoView();
                
        // });
        
            
    //    });

    });
// function scrollimage2(){
    
// }
// function scrollimage3(){
//     let backimages2=document.getElementById('backimages2');
//     backimages2.scrollIntoView();
// }
// function scrollimage2(){
//     let backimages2=document.getElementById('backimages2');
//     backimages2.scrollIntoView();
// }